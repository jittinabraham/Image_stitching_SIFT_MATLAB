function [stitched_img] = stitch_images(a, b, dx, dy)
% Stitch two images together and return a color image stitched together

% Convert input images to double precision
a = im2double(a);
b = im2double(b);

% Calculate the size of the stitched image
rows_a = size(a, 1);
cols_a = size(a, 2);
rows_b = size(b, 1);
cols_b = size(b, 2);
max_rows = max(rows_a, rows_b);
max_cols = max(cols_a, cols_b);
min_rows = min(rows_a, rows_b);
min_cols = min(cols_a, cols_b);
stitched_rows = max_rows + abs(dy);
stitched_cols = max_cols + abs(dx);

% Initialize the stitched image as a black image
stitched_img = zeros(stitched_rows, stitched_cols, 3);

% Compute the starting row and column indices for the images
if dx < 0
    start_col_a = 1;
    start_col_b = abs(dx) + 1;
else
    start_col_a = dx + 1;
    start_col_b = 1;
end
if dy < 0
    start_row_a = 1;
    start_row_b = abs(dy) + 1;
else
    start_row_a = dy + 1;
    start_row_b = 1;
end

% Copy image a into the stitched image
stitched_img(start_row_a:start_row_a+rows_a-1, start_col_a:start_col_a+cols_a-1, :) = a;

% Copy image b into the stitched image, averaging where they overlap
for row = 1:min_rows
    for col = 1:min_cols
        if b(row, col, 1) ~= 0 || b(row, col, 2) ~= 0 || b(row, col, 3) ~= 0
            stitched_img(start_row_b+row-1, start_col_b+col-1, :) = ...
                (stitched_img(start_row_b+row-1, start_col_b+col-1, :) + b(row, col, :)) / 2;
        end
    end
end

% Display the stitched image


end