function [dx, dy] = image_shift_trans(best_matches)
    % Calculate the difference between the coordinates of the matching features
    dx = median(best_matches(:,1) - best_matches(:,3));
    dy = median(best_matches(:,2) - best_matches(:,4));
end
