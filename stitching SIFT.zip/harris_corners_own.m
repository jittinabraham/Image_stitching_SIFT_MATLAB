function [r, c, log_im] = harris_corners_own (Im1_gray,sigma,radius,threshold)
    gradient_x_kernal=[-1 0 1; -2 0 2 ;-1 0 1];
    gradient_y_kernal=gradient_x_kernal';
    %Im2_gray_x=imfilter(Im2_gray,gradient_x_kernal,"conv")
    %Im2_gray_y=imfilter(Im2_gray,gradient_y_kernal,"conv")
    Im1_gray_x=imfilter(im2double(Im1_gray),gradient_x_kernal,"conv");
    Im1_gray_y=imfilter(im2double(Im1_gray),gradient_y_kernal,"conv");
    hsize = 2 * ceil(3 * sigma) + 1;
    G=fspecial("gaussian",hsize,sigma);
    %gradient squares
    Gx2=Im1_gray_x.^2;
    Gy2=Im1_gray_y.^2;
    Gxy=Im1_gray_x.*Im1_gray_y;
    %Gaussian 
    Gx2=imfilter(Gx2,G,"conv");
    Gy2=imfilter(Gy2,G,"conv");
    Gxy=imfilter(Gxy,G,"conv");
    % Compute the corner response function
    M=[Gx2 Gxy;Gxy Gy2];
    C = (Gx2.*Gy2 - Gxy.^2)-0.04*(Gx2+Gy2).^2;
    
    C2=(Gx2 .* Gy2 - Gxy .^ 2) ./ (Gx2 + Gy2 + eps);
    size_=zeros(1,2);
    size_=size(C2);
    for i=1:size_(1,1)
        for j=1:size_(1,2)
            if C2(i,j)<0.04
                C2(i,j)=0;
            end
        end
    end
    for i=1:size_(1,1)
        for j=1:size_(1,2)
            if C(i,j)<0.04
                C(i,j)=0;
            end
        end
    end
    C2=and(C,C2);
    
    maxima = ordfilt2(C2, radius ^ 2, ones(radius * 2 + 1));
    C2 = (C2== maxima)&C2>=threshold;
    [r, c] = find(C2)
    
    log_im=C2>0
   
    end