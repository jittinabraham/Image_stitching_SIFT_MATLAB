clear all
close all
addpath(genpath('images'));
Im1=imread('a.bmp');
Im2=imread('b.bmp');
Im1_gray=rgb2gray(Im1);
Im2_gray=rgb2gray(Im2);
descriptor_size=15;

radius =2;
sigma=1.6;
threshold=0.04;


[r, c, log_im] = harris_corners_own (Im1_gray,sigma,radius,threshold);
[r2,c2,log_im2] = harris_corners_own(Im2_gray,sigma,radius,threshold);
%r , c  corners of Image 1
%r2,c2 corners of Image 2;


[descriptor_list_1] = calc_descriptor(r, c,Im1_gray, descriptor_size);
[descriptor_list_2] = calc_descriptor(r2, c2,Im2_gray, descriptor_size);
%each row of descriptor1 describes rows and colums of corner points of
%image and 2 respectively


matches=descriptor_dis(descriptor_list_1,descriptor_list_2);
%the first colum of matches corresponds to the row of the descriptor_list_2
%which corresponds to the corners of Image2
%the second colum of the matces corresponds to the row of the
%descriptor_list_2 which corrsponds the corners of Image 1
threshold=0.000008;
keep_rows=matches(:,3)<threshold;
filterd_matches=matches(keep_rows,:);
rB=r(filterd_matches(:,2));
cB=c(filterd_matches(:,2));
rB2=r2(filterd_matches(:,1));
cB2=c2(filterd_matches(:,1));
best_matches=[rB,cB,rB2,cB2,filterd_matches(:,3)];
best_matches = sortrows(best_matches,5 )

[dx, dy] = image_shift_trans(best_matches)
[stitched_img] = stitch_images(Im2,Im1, dx, dy);

imshow(stitched_img);


% Plot the matched feature points with the shortest distance
