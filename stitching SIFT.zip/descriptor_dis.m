function matches=descriptor_dis(descriptor_list_1,descriptor_list_2);


x=min(length(descriptor_list_1),length(descriptor_list_2));
min_distance=zeros(x,1);
matches = zeros(x,3);
row_descriptor_2=zeros(x,1);
row_descriptor_1=zeros(x,1);


for i=1:length(descriptor_list_2)
    for j=1:length(descriptor_list_1)
            temp=sqrt(sum(descriptor_list_2(i,:)-descriptor_list_1(j,:)).^2);
            if(j==1)
                min_distance(i)=temp;
                row_descriptor_2(i)=1;
            end
            if(j~=1)&&(min_distance(i)>temp)
                min_distance(i)=temp;
                row_descriptor_2(i)=j;
             end
    end
    row_descriptor_1(i)=i;
    
end
matches=[row_descriptor_1 row_descriptor_2 min_distance];
end