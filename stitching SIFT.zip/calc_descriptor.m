function descriptor_list = calc_descriptor(r, c,Im_gray, descriptor_size)
   
    % Inputs:
% - r: Row coordinates of Harris corners
% - c: Column coordinates of Harris corners
% - I: Input grayscale image
% - descriptor_size: Size of the descriptor patch (assumed to be odd)

% Outputs:
% - descriptor_list: List of descriptors for each Harris corner

% Initialize descriptor list
descriptor_list = zeros(length(r), descriptor_size);

% Pad image borders to handle corners near image edges
%pad_size = floor(descriptor_size/2);
%Im_gray = padarray(Im_gray, [pad_size pad_size], 'replicate');
%[im_height, im_width] = size(Im_gray);
% Loop over all Harris corners

for i = 1:length(r)
    
      temR=r(i);
      temC=c(i);
    patch = Im_gray((temR-1:temR+1) ,(temC-2:temC+2));
    
    % Normalize patch to length 1
    patch = double(patch(:)) / norm(double(patch(:)));
    
    % Add patch descriptor to list
    descriptor_list(i, :) = patch';
end


end
    
    
    
